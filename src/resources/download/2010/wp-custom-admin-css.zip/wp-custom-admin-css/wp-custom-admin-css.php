<?php
/*
Plugin Name: WP Custom Admin CSS
Plugin URI: 
Description: 管理画面に CSS を追加するだけのプラグイン。変更はプラグインディレクトリ内のスタイルシートを直接編集してください。WordPress 2.8 以降のみ対応。
Version: 1.00
Author: Matori/ub-pnr
Author URI: http://unformedbuilding.com/
*/

/*  Copyright 2010 Matori/ub-pnr (email : pnr.matori@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


function wp_custom_admin_css() {

	/*-- 全てのユーザーに適用 --*/
	echo "\n" . '<link rel="stylesheet" type="text/css" href="' . plugin_dir_url(__FILE__) . 'wp-custom-admin-css.css' . '" />' . "\n";

	/*-- ユーザー権限別に適用（使う場合はコメントアウトを解除してください） --*/
/*
	$current_user = wp_get_current_user();
	$user_lv = $current_user->user_level;

	// 権限：管理者(Administrator)
	if($user_lv > 7) {
		$cssfilename = 'administrator'; // 適用させる CSS のファイル名
	}

	// 権限：編集者(Editor)
	if($user_lv > 4 && $user_lv < 8) {
		$cssfilename = 'editor';
	}

	// 権限：投稿者(Author)
	if($user_lv > 1 && $user_lv < 5) {
		$cssfilename = 'author';
	}

	// 権限：寄稿者(Contributor)
	if($user_lv === 1) {
		$cssfilename = 'contributor';
	}

	// 権限：購読者(Subscriber)
	if($user_lv === 0) {
		$cssfilename = 'subscriber';
	}

	echo "\n" . '<link rel="stylesheet" type="text/css" href="' . plugin_dir_url(__FILE__) . 'role/' . $cssfilename . '.css' . '" />' . "\n";
*/
}

add_action('admin_head', 'wp_custom_admin_css', 100);
?>