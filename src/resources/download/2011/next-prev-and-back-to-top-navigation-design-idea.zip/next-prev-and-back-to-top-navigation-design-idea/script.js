jQuery(function () {

// for demo
$('.nav').children('a').click(function (e) {
  e.preventDefault();
});

});